// gcc contadorw.c -o contadorwC $(sdl2-config --cflags --libs)

#include <windows.h>
#include <SDL2/SDL.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
    AllocConsole();

    freopen("CONOUT$", "w", stdout);
    freopen("CONOUT$", "w", stderr);
    freopen("CONIN$", "r", stdin);

    printf("Programa iniciado. Escreva algum texto aqui:\n");

    char zz[99];

    if (fgets(zz, sizeof(zz), stdin) != NULL)
    {
        size_t len = strlen(zz);

        if (len > 0 && zz[len - 1] == '\n')
            zz[len - 1] = '\0';

        printf("\nEste texto: %s aqui.\n", zz);
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0)
    {
        printf("Erro ao iniciar SDL: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window *window = SDL_CreateWindow(
        "Botao",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        800,
        600,
        0
    );

    if (!window)
    {
        printf("Erro ao criar janela: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Renderer *renderer = SDL_CreateRenderer(
        window,
        -1,
        SDL_RENDERER_ACCELERATED |
        SDL_RENDERER_PRESENTVSYNC
    );

    if (!renderer)
    {
        printf("Erro ao criar renderer: %s\n", SDL_GetError());

        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    SDL_Rect button = {300, 250, 200, 100};

    int contador = 0;
    int running = 1;

    while (running)
    {
        SDL_Event e;

        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_QUIT)
            {
                running = 0;
            }

            else if (e.type == SDL_MOUSEBUTTONDOWN)
            {
                int x = e.button.x;
                int y = e.button.y;

                if (x >= button.x &&
                    x <= button.x + button.w &&
                    y >= button.y &&
                    y <= button.y + button.h)
                {
                    contador++;

                    printf("Contador = %d\n", contador);
                    fflush(stdout);
                }
            }
        }

        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderDrawColor(renderer, 0, 120, 255, 255);
        SDL_RenderFillRect(renderer, &button);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();

    return 0;
}
