#include <stdio.h>
#include <string.h>

int main() {
    while (1) {
        char x[9999];
        char y[9999];
        printf("\nString (1):\n");
        fgets(x, sizeof(x), stdin);
        printf("\nString (2):\n");
        fgets(y, sizeof(y), stdin);

        if (strcmp(x, y) == 0) {
            printf("\nResultado: igual\n");
        }
        else {
            printf("\nResultado: diferente\n");
        }

        printf("\n");
        for (int i = 0; i<50; i++) {
            printf("=");
        }
        printf("\n");
    }
    return 0;
}
