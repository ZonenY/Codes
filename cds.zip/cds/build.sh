gcc comparador_string.c -o comparador_stringA_C
