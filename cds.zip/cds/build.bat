gcc comparador_string.c -o comparador_stringW_C
