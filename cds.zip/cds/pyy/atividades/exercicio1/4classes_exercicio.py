class Conta:
    def __init__(self):
        self.saldo = 0

    @staticmethod
    def proibe(valor):
        if valor <= 0:
            raise ValueError('Erro. O valor não pode ser menor ou igual a zero.')

    @property
    def saldo(self):
        return self._saldo
    @saldo.setter
    def saldo(self, valor):
        if valor < 0:
            raise ValueError('Erro. O valor não pode ser menor que zero.')
        self._saldo = float(valor)

    def depositar(self, valor):
        self.proibe(valor)
        self.saldo += float(valor)
        print(f'Deposito de R$: {valor} realizado com sucesso')
        print(f'SEU NOVO SALDO É R$: {self.saldo}')

    def sacar(self, valor):
        self.proibe(valor)
        if self.saldo >= valor:
            self.saldo -= valor
            print(f'Saque de R$:{valor} Realizado com sucesso')
            print(f'SEU NOVO SALDO É R$: {self.saldo}')
        else:
            print('Saldo insuficiente para saque')


def exercicio(objeto):
    while True:
        escolha = input('\nDigite 1 para Depositar.\nDigite 2 para Sacar.\nDigite 3 para Ver Saldo.\nDigite 4 para Sair.\n')
        if escolha == '1':
            x = int(input('\nDigite o valor que quer depositar:'))
            print('')
            objeto.depositar(x)
        elif escolha == '2':
            x = int(input('\nDigite o valor que quer sacar:'))
            print('')
            objeto.sacar(x)
        elif escolha == '3':
            print(f'\nO seu saldo é de: {objeto.saldo}R$')
        elif escolha == '4':
            print('\nEncerrado.')
            break
        print('\n' + '='*50)

#=========================================

class Produto:
    def __init__(self, nome, preco):
        self.nome = nome
        self._preco = float(preco)

    @property
    def preco(self):
        return self._preco
    @preco.setter
    def preco(self, novo_preco):
        if isinstance(novo_preco, (int, float)) and novo_preco >= 0:
            self._preco = float(novo_preco)
        else:
            print('Valor inválido. O preço deve ser numérico.')

class Modificador:
    @staticmethod
    def maiusculo(valor):
        return valor.upper()

    @staticmethod
    def minusculo(valor):
        return valor.lower()

    @staticmethod
    def capitalizar(valor):
        return valor.capitalize()

    @staticmethod
    def remover_espacos(valor):
        return valor.strip()

def exercicio2():
    nome_produto = input('Nome do Produto: ')
    nomesModificados = {
            'maiusculo': Modificador.maiusculo(nome_produto),
            'minusculo': Modificador.minusculo(nome_produto),
            'capitalizado': Modificador.capitalizar(nome_produto),
            'espaco_removido': Modificador.remover_espacos(nome_produto)
    }
    produto1 = Produto(nomesModificados['maiusculo'], 50)

    print('\nResultado final:')
    for i in nomesModificados.keys():
        produto1 = Produto(nomesModificados[i], 50)
        print(f'{produto1.nome} -> R$:{produto1.preco}')

    produto1 = Produto(nomesModificados['maiusculo'], 50)
    print(f'\nProduto:')
    print(f'{produto1.nome} -> R$:{produto1.preco}')


