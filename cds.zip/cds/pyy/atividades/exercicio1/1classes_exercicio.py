class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade
    def apresentar(self):
        print(f'O nome da pessoa é: {self.nome}. Sua idade é: {self.idade}')
        
#=========================================

class Deposito:
    def __init__(self):
        self.saldo = 0
    def depositar(self, valor):
        self.saldo += valor
        print(f'Saldo: {self.saldo}')

conta = Deposito()

