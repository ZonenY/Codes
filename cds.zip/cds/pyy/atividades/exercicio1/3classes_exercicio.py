import secrets
class Personagem:
    def __init__(self, nome, vida):
        self.nome = nome
        self.vida = vida

    @property
    def vida(self):
        return self.__vida

    @vida.setter
    def vida(self, valor):
        if valor < 0:
            self.__vida = 0
        elif valor > 100:
            self.__vida = 100
        else:
            self.__vida = valor

    def atacar(self):
        return 0

    def ataque(self, valor):
        if valor < 0:
            print('O Personagem não pode ter valores negativos de ataque')
            ataque = secrets.randbelow(31)
        elif valor > 30:
            print('O Personagem não pode ter valores acima de 30')
            ataque = 30
        else:
            ataque = valor
        return ataque

class Mago(Personagem):
    def __init__(self, nome, vida, magia):
        super().__init__(nome, vida)
        self.magia = super().ataque(magia)

    @property
    def ataque(self):
        return self.magia

    @ataque.setter
    def ataque(self, valor):
        self.magia = super().ataque(valor)

class Guerreiro(Personagem):
    def __init__(self, nome, vida, forca):
        super().__init__(nome, vida)
        self.forca = super().ataque(forca)
    
    @property
    def ataque(self):
        return self.forca

    @ataque.setter
    def ataque(self, valor):
        self.forca = super().ataque(valor)


