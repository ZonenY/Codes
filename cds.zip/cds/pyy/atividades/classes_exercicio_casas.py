# ===========================================

# INSTRUÇÕES:
# 1. Complete o código abaixo implementando as funcionalidades solicitadas
# 2. NÃO altere a estrutura básica
# 3. Utilize os conceitos de POO vistos em aula

# ===========================================
# QUESTÃO 1: CLASSE BASE CASA (3.0 pontos)
# ===========================================

class Casa:
    """
    Classe base para representar uma casa.
    """

    # TODO 1 e 2: Dentro de __init__, Crie os atributos:
    # - numero (público)
    # - proprietario (público)
    # - _area (privado)
    # - _ocupada (privado - booleano)

    def __init__(self, numero, proprietario, area):
        """
        TODO 1 e 2: Apague o pass abaixo e inicialize os atributos listados no TODO 1.:
        - Obs: _ocupada começa como False
        """
        self.numero = numero
        self.proprietario = proprietario
        self._area = area
        self._ocupada = False

    # TODO 3: Getters e Setters:
    # - Getter e Setter para area -(Crie uma logica dentro do @staticmethod validar_area para validar se > 0 e use no setter)
    # - Nao esqueça que para usar o staticmethod voce precisa chamar a classe Casa.validar_area(...)
    # - Crie apenas o getter para _ocupada (objetivo é apenas ler o status de ocupada ou não)

    @staticmethod
    def validar_(valor):
        if valor <= 0:
            raise ValueError
    @property
    def area(self):
        return self._area
    @area.setter
    def area(self,valor):
        Casa.validar_(valor)
        self._area=valor
    @property
    def ocupada(self):
        return self._ocupada

    def ocupar(self):
        """
        TODO 4:
        - Verifica Se NÃO esta ocupada
            - Se não estiver ocupada, marcar como ocupada (True)
            - Retornar True no metodo se ocupou com sucesso
        - Se já estiver ocupada, retornar False no metodo
        """
        if self._ocupada == False:
            self._ocupada = True
            return True
        else:
            return False

    def desocupar(self):
        """
        TODO 5:
        - Verifica Se esta ocupada
            - Se estiver ocupada, marcar como desocupada (False)
            - Retornar True no metodo se desocupou com sucesso
        - Se já estiver desocupada, retornar False no metodo
        """
        if self._ocupada == True:
            self._ocupada = False
            return True
        else:
            return False
    # >>>>> ATENÇÃO <<<<<<
    # METODDO __str__ JA IMPLEMENTADO PARA FACILITAR TESTES, >>>> NAO ALTERE <<<<<
    def __str__(self):
        status = "Ocupada" if self._ocupada else "Disponível"
        return f"Casa {self.numero} - {self.proprietario} - {status} - {self._area} m²"


    # TODO 6: Método estático para validar área (> 0) (se area for valida, retorne True, senão False)
    @staticmethod
    def validar_area(area):
        if area > 0:
            return True
        else:
            return False


    # TODO 7: Método de classe criando casa exemplo
    # Esse metodo de classe deve criar e retornar um objeto casa com os seguintes dados:
    # Retorne: numero=1, proprietario="João", area=100
    # OBS: nao use self, use cls no retorno para criar o objeto
    @classmethod
    def criando_casa_exemplo(cls):
        return cls(1, "João", 100)


# ===========================================
# QUESTÃO 2: HERANÇA - CASA LUXO (2.0 pontos)
# ===========================================

class CasaLuxo(Casa):
    """
    Classe que representa casas de alto padrão.
    """
    
    def __init__(self,numero, proprietario, area, piscina, vagas):
        super().__init__(numero, proprietario, area)
        """
        TODO 8:
        - Chamar construtor da classe pai (super().__init__(...))
        - Criar atributos:
            _piscina (booleano)
            _vagas_garagem
        """
        self._piscina = piscina
        self._vagas_garagem = vagas
    
    # TODO 9: Getters e Setters:
    # - getter e setter para vagas_garagem (com validação para ser >= 0)
    # - getter e setter para piscina (sem validação, apenas para ler e escrever o valor))

    @property
    def vagas_garagem(self):
        return self._vagas_garagem
    @vagas_garagem.setter
    def vagas_garagem(self,valor):
        if valor<0:
            raise ValueError
        self._vagas_garagem=valor
    @property
    def piscina(self):
        return self._piscina
    @piscina.setter
    def piscina(self,buleano):
        self._piscina = buleano

    # TODO 10: Método específico
    def detalhes(self):
        """
        Esse metodo quando chamado deve retornar uma string com os detalhes da casa luxo, seguindo o formato abaixo:
        Retorne:
        "Vagas: X - Piscina: Y - Área: Z m²"
        """
        return f'Vagas: {self._vagas_garagem} - Piscina: {self._piscina} - Área: {self._area} m²'

# ===========================================
# QUESTÃO 3: POLIMORFISMO - CONDOMÍNIO (3.0 pontos)
# ===========================================

class Condominio:
    """
    Classe para gerenciar casas.
    """
    
    def __init__(self, nome):
        """
        TODO 11:
        - Inicialize os seguintes atributos:
        - nome
        - lista de casas (deve ser inicializada como lista vazia para armazenar as casas do condomínio)
        """
        self.nome = nome
        self.casas = []
    
    def adicionar_casa(self, casa):
        """
        TODO 12:
        Crie a estrutura para Adicionar casa à lista
        """
        self.casas.append(casa)
    
    def listar_casas(self):
        """
        TODO 13:
        - Mostrar nome do condomínio (use print)
        - Listar todas as casas (usar polimorfismo dentro de uma estrutura for)
        """
        print(self.nome)
        for i in self.casas:
            print(i)
    
    def buscar_casa_por_numero(self, numero):
        """
        TODO 14:
        - Crie uma estrutura para buscar casa pelo número (percorrendo a lista de casas)
        - Buscar casa pelo número
        - O retorno do metodo deve ser a casa (se encontrada) ou None (se não encontrada)
        """
        for i in self.casas:
            if i.numero==numero:
                return i
    
    def ocupar_casa(self, numero):
        """
        TODO 15:
        - Buscar casa (use o método buscar_casa_por_numero ja criado)
        - Se casa encontrada, Tentar ocupar
            - tente ocupar usando o método ocupar da classe Casa (polimorfismo)
            - Se ocupou com sucesso, retorne mensagem "Casa X ocupada com sucesso!"
            - Se já estava ocupada, retorne mensagem "Casa X já está ocupada."
        - Se casa não for encontrada, retorne "Casa não encontrada"
        - Retornar mensagens adequadas
        """
        h=self.buscar_casa_por_numero(numero)
        if h==None:
            return 'Casa não encontrada'
        else:
            hh=h.ocupar()
            if hh==False:
                return f'Casa {h.numero} já está ocupada.'
            else:
                return f'Casa {h.numero} ocupada com sucesso!'
    
    def desocupar_casa(self, numero):
        """
        TODO 16:
        - Buscar casa (use o método buscar_casa_por_numero ja criado)
        - Se casa encontrada, Tentar desocupar
            - tente desocupar usando o método desocupar da classe Casa
            - Se desocupou com sucesso, retorne mensagem "Casa X desocupada com sucesso!"
            - Se já estava desocupada, retorne mensagem "Casa X já está desocupada."
        - Se casa não for encontrada, retorne "Casa não encontrada"
        - Retornar mensagens adequadas
        """
        h=self.buscar_casa_por_numero(numero)
        if h==None:
            return 'Casa não encontrada'
        else:
            hh=h.desocupar()
            if hh==False:
                return f'Casa {h.numero} já está desocupada.'
            else:
                return f'Casa {h.numero} desocupada com sucesso!'

    
    # ATENÇÃO: O método de classe abaixo já está implementado para facilitar os testes
    # >>>> NAO ALTERE <<<<<
    @classmethod
    def criar_condominio_exemplo(cls):
        cond = cls("Residencial Azul")
        
        c1 = CasaLuxo(1, "Ana", 120, True, 2)
        c2 = CasaLuxo(2, "Carlos", 90, False, 1)
        
        cond.adicionar_casa(c1)
        cond.adicionar_casa(c2)
        
        return c1


# Crie seus testes aqui embaixo
# (NAO OBRIGATÓRIO, MAS RECOMENDADO PARA TESTAR SEU CODIGO FUNCIONA CORRETAMENTE)
