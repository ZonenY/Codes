from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives import serialization
import hmac
import hashlib
import os
import base64

def undoK(a):
    return x25519.X25519PrivateKey.from_private_bytes(a)
def undoP(a):
    return x25519.X25519PublicKey.from_public_bytes(a)
def bytes_obtainP(a):
    x = a.public_bytes(
    encoding = serialization.Encoding.Raw,
    format = serialization.PublicFormat.Raw
)
    return x


def base64_(data: bytes):
    return base64.b64encode(data).decode()
def desbase64_(data):
    return base64.b64decode(data)
def hmac_(key: bytes, data: bytes):
    hmac_result = hmac.new(key, data, hashlib.sha256).digest()
    return hmac_result
def hkdf_(ikm: bytes, salt: bytes, info: bytes, leng: int):
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=leng,
        salt=salt,
        info=info,
    )

    key = hkdf.derive(ikm)
    return key
def diffie(privatekey: bytes, peerpubkey: bytes):
    private_key = undoK(privatekey)
    public_key = private_key.public_key()
    bb = undoP(peerpubkey)
    keey = private_key.exchange(bb)
    return keey

class Criptor:
    def __init__(self):
        escolha3 = input('\nSomente use chave em base64 se souber o que está fazendo.\n(0) para chave em ascii, (1) para chave em base64:\n')
        RK = input('\n(Root key) Inserir chave principal:\n')
        if escolha3 == '1':
            RK = base64.b64decode(RK)
        else:
            RK = RK.encode()
        while len(RK) < 32:
            RK = RK + b'\x00'
        
        privatekey = os.urandom(32)
        publickey = undoK(privatekey).public_key()
        print('\nEnvie este codigo para o amigo:')
        print(base64.b64encode(bytes_obtainP(publickey)).decode())
        bobpubkey = input('\nColoque aqui o codigo recebido:\n')
        DHout = diffie(privatekey, base64.b64decode(bobpubkey))
        
        self.RK = RK
        self.CKr_principal = None
        self.DHout = DHout
        self.priv = privatekey
        self.pub = base64.b64decode(bobpubkey)
        
        self.CKs = None
        self.CKr = None
        self.CKcount = 0
        self.MK = None
        self.bool1 = 0
        self.bool2 = 0
        self.counter = 1
        self.TT = True
        
    @staticmethod
    def aesgcmcrypt(data: bytes, key: bytes):
        data = data
        iv = os.urandom(12)
        cipher=AESGCM(key).encrypt(iv, data, None)
        data2 = iv + cipher
        return data2
    
    @staticmethod
    def aesgcmdecrypt(data: bytes, key: bytes):
        dataiv = data
        iv = dataiv[:12]
        data = dataiv[12:]
        plaintext = AESGCM(key).decrypt(iv, data, None)
        return plaintext
    
    @staticmethod
    def KDF_RK(RK: bytes, DHout: bytes):
        aa = hkdf_(DHout, RK, b'DoubleRatchet', 64)
        RK_new = aa[0:32]
        CK_new = aa[32:64]
        return (RK_new, CK_new)
    
    @staticmethod
    def KDF_CK(CK: bytes):
        CK_new = hmac_(CK, b'\x01')
        MK = hmac_(CK, b'\x02')
        return (CK_new, MK)

    #fazer diffie hellman se True
    def xor_(self, a, b):
        if self.TT == True:
            return True
        elif (a or b) and not (a and b):
            return True
        else:
            return False

    def crypt_(self):
        if self.counter == 0:
            self.bool1 = 1
        else:
            self.bool2 = 1
        bool2 = self.xor_(self.bool1, self.bool2)
        if bool2 == True:
            self.CKcount = 0
            self.priv = os.urandom(32)
            publickey = undoK(self.priv).public_key()
            self.DHout = diffie(self.priv, self.pub)
            self.RK, self.CK = self.KDF_RK(self.RK, self.DHout)
            self.CKs, self.CKr = (self.CK, self.CK)
            self.CKs, self.MK = self.KDF_CK(self.CKs)
            plain_ = input('\nDigite a mensagem.:\n')
            result = bytes_obtainP(publickey)+self.aesgcmcrypt(plain_.encode(), self.MK)
            print(f'\nCiphertext:\n{base64.b64encode(result).decode()}-')
        else:
            self.CKcount += 1
            self.CKs, self.MK = self.KDF_CK(self.CKs)
            plain_ = input('\nDigite a mensagem:\n')
            result = self.CKcount.to_bytes(4, "big")+self.aesgcmcrypt(plain_.encode(), self.MK)
            print(f'\nCiphertext:\n{base64.b64encode(result).decode()}')
    def decrypt_(self):
        if self.counter == 0:
            self.bool1 = 0
        else:
            self.bool2 = 0
        bool2 = self.xor_(self.bool1, self.bool2)
        if bool2 == True:
            self.CKcount = 0
            cipher_ = input('\nColoque ciphertext enviado.:\n')
            cipher_ = base64.b64decode(cipher_[:-1])
            self.pub, cipher_ = cipher_[:32], cipher_[32:]
            self.DHout = diffie(self.priv, self.pub)
            self.RK, self.CK = self.KDF_RK(self.RK, self.DHout)
            self.CKs, self.CKr = (self.CK, self.CK)
            self.CKr, self.MK = self.KDF_CK(self.CKr)
            self.CKr_principal = self.CKr
            result = self.aesgcmdecrypt(cipher_, self.MK)
            print(f'\nMensagem:\n{result.decode()}')
        else:
            self.CKr, self.MK = self.KDF_CK(self.CKr)
            cipher_ = input('\nColoque ciphertext enviado:\n')
            if cipher_[-1]=='-':
                print('\nNao e possivel decifrar a primeira mensagem depois da troca.')
                return 0
            result = base64.b64decode(cipher_)
            self.CKcount = int.from_bytes(result[0:4], byteorder="big")
            try:
                result2 = self.aesgcmdecrypt(result[4:], self.MK)
            except:
                self.CKr = self.CKr_principal
                for i in range(self.CKcount):
                    self.CKr, self.MK = self.KDF_CK(self.CKr)
                result2 = self.aesgcmdecrypt(result[4:], self.MK)
            print(f'\nMensagem:\n{result2.decode()}')



def main():
    cifrinha = Criptor()
    while True:
        escolha = input('\n(0) para cifrar, (1) para decifrar.\nDigite "/sair" para sair.\nDigite "/clear" para limpar a tela.\n')
        if escolha == '/clear':
            os.system('cls' if os.name == 'nt' else 'clear')
            continue
        elif escolha == '/sair':
            exit()
        cifrinha.counter = (cifrinha.counter+1)%2
        if escolha == '0':
            cifrinha.crypt_()
        elif escolha == '1':
            cifrinha.decrypt_()
        else:
            raise ValueError('Nenhuma opcao valida foi escolhida')
        print('\n' + '=' * 50)
        cifrinha.TT = False

if __name__ == '__main__':
    main()
