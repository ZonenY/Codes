import hashlib
import base64
import time
#hashname,password,salt,iterations,dklen=(None padrao)
print('(Tudo em base64.)')
while True:
    senha=base64.b64decode(input('\nSenha:\n'))
    salt=base64.b64decode(input('\nSalt:\n'))
    ite=int(input('\nIteracoes:\n'))
    byt=int(input('\nTamanho da chave em bytes:\n'))
    #a em bytes
    start = time.perf_counter()
    a=hashlib.pbkdf2_hmac('sha256',senha,salt,ite,byt)
    end = time.perf_counter()
    print(f'\nResultado:\n{base64.b64encode(a).decode()}')
    print(f'\nTempo de calculo:\n{end - start:.6f} segundos')
    print('\n' + '=' * 50)
