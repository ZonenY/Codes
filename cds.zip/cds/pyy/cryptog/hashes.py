import hashlib
import base64
print('(Tudo em hexadecimal.)\n')
while True:
    texto = input("\nInput:\n")
    dados=bytes.fromhex(texto)

    # hashlib.sha256 , hashlib.new('ripemd160').copy
    sha256 = hashlib.sha256(dados).hexdigest()
    ripemd160 = hashlib.new('ripemd160', dados).hexdigest()

    print(f'\nSHA256:\n{sha256}')
    print(f'\nripemd160:\n{ripemd160}')
    print('\n' + '=' * 50)
