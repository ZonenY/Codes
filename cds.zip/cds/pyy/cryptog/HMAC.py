import hmac
import hashlib
import base64

print('\n(Tudo em base64.)')
while True:
    message=base64.b64decode(input('\nMessage:\n'))
    key=base64.b64decode(input('\nChave:\n'))

    # hashlib.sha256 , hashlib.new('ripemd160').copy
    hmac_result = hmac.new(key, message, hashlib.sha256).digest()
    hmac_result=base64.b64encode(hmac_result).decode()
    h = hmac.new(key, message, hashlib.new('ripemd160').copy)
    hmac_ripemd160 = h.digest()
    hmac_ripemd160=base64.b64encode(hmac_ripemd160).decode()
    print(f"\nHMAC(ripemd160):\n{hmac_ripemd160}")
    print(f"\nHMAC(sha-256):\n{hmac_result}")
    print('\n' + '=' * 50)
