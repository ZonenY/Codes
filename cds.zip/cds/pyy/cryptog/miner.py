import hashlib
import multiprocessing
import time
import os


def worker(start_nonce, step, data, difficulty, result):

    prefix = "0" * difficulty
    nonce = start_nonce

    while True:

        message = f"{data}{nonce}".encode()
        h = hashlib.sha256(message).hexdigest()

        if h.startswith(prefix):
            result.put((nonce, h))
            return

        nonce += step


def mine_parallel(data, difficulty):

    cpu_count = os.cpu_count()
    result = multiprocessing.Queue()
    processes = []

    start = time.time()

    for i in range(cpu_count):

        p = multiprocessing.Process(
            target=worker,
            args=(i, cpu_count, data, difficulty, result)
        )

        p.start()
        processes.append(p)

    nonce, h = result.get()

    elapsed = time.time() - start

    print(f'\nEntrada:\n{data}{nonce}')
    print(f'\nHash:\n{h}')
    print(f'\nNonce:\n{nonce}')
    print(f'\nTempo de calculo:\n{elapsed} segundos')
    print(f'\nCores usados:\n{cpu_count}')

    for p in processes:
        p.terminate()


def main():
    while True:
        str0 = input('\nString:\n')
        diff0 = int(input('\nDificuldade:\n'))
        mine_parallel(str0, diff0)
        print('\n' + '=' * 50)

if __name__ == '__main__':
    main()
