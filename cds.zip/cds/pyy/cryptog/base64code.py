import base62
import base64
import base91
#Função do base64->bytes
def bytes_formato(bs:bytes)->str:
    out=[]
    for b in bs:
        if 32<=b<=126:  # ASCII
            out.append(chr(b))
        else:
            out.append(f'\\x{b:02x}')
    return ''.join(out)
#Função do base62-base64
def int_bytes(n:int)->bytes:
    length=(n.bit_length()+7)//8 or 1
    return n.to_bytes(length, "big")
print('\n\n')
print(r'[Aviso: Ao transformar bytes-base64, lembre-se de representar barra inversa como "\\" em vez de "\"]')
print('Encodings: [hex, base91, base64, base62, base32, bytes]')
print('Apenas base64 -> encoding e encoding -> base64')
while True:
    print('\n' + '=' * 50)
    text=input('\n-----' + 'TEXTO' + '-----:\n')
    # Hex -> Base64
    try:
        bytes_data = bytes.fromhex(text)
        base64_encoded = base64.b64encode(bytes_data).decode()
        print(f"\nHex -> Base64:\n{base64_encoded}")
    except:
        print("\nHex -> Base64: [Erro.]")

    # Base64 -> Hex
    try:
        bytes_from_base64 = base64.b64decode(text)
        hex_encoded = bytes_from_base64.hex()
        print(f"\nBase64 -> Hex:\n{hex_encoded}")
    except:
        print("\nBase64 -> Hex: [Erro.]")
    #Base64 -> Bytes
    try:
        pp=base64.b64decode(text)
        print(f'\nBase64 -> Bytes:\n{bytes_formato(pp)}')
    except:
        print("\nBase64 -> Bytes: [Erro.]")
    #Bytes -> Base64
    try:
        text3=text.encode().decode("unicode_escape").encode()
        print(f'\nBytes -> Base64:\n{base64.b64encode(text3).decode()}')
    except:
        print(f'\nBytes -> Base64: [Erro.]')
    #Base64 -> Base91
    try:
        text91=base64.b64decode(text)
        b91=base91.encode(text91)
        print(f'\nBase64 -> Base91:\n{b91}')
    except:
        print("\nBase64 -> Base91: [Erro.]")
    #Base91 -> Base64
    try:
        ab91=base91.decode(text)
        ab64=base64.b64encode(ab91).decode()
        print(f'\nBase91 -> Base64:\n{ab64}')
    except:
        print(f'\nBase91 -> Base64: [Erro]')
    #Base64 -> Base32
    try:
        cb64=base64.b64decode(text)
        cb32=base64.b32encode(cb64).decode()
        print(f'\nBase64 -> Base32:\n{cb32}')
    except:
        print('\nBase64 -> Base32: [Erro.]')
    #Base32 -> Base64
    try:
        db32=base64.b32decode(text)
        db64=base64.b64encode(db32).decode()
        print(f'\nBase32 -> Base64:\n{db64}')
    except:
        print('\nBase32 -> Base64: [Erro.]')
    #Base64 -> Base62
    try:
        eb64=base64.b64decode(text)
        enum=int.from_bytes(eb64, "big")
        eb62=base62.encode(enum)
        print(f'\nBase64 -> Base62:\n{eb62}')
    except:
        print('\nBase64 -> Base62: [Erro.]')
    #Base62 -> Base64
    try:
        fb62=base62.decode(text)
        fInt=int_bytes(fb62)
        fb64=base64.b64encode(fInt).decode()
        print(f'\nBase62 -> Base64:\n{fb64}')
    except:
        print('\nBase62 -> Base64: [Erro.]')
