import base64
import os

print('\n(Tudo em base64.)')
while True:
    n=int(input('\nTamanho em bytes:\n'))
    m=base64.b64encode(os.urandom(n)).decode()
    print(f'\nBytes gerados:\n{m}')
    print('\n' + '=' * 50)
