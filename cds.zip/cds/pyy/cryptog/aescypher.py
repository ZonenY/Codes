import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os
def limp():
    os.system('cls' if os.name=='nt' else 'clear')
def cifrar(ivAuto):
    if ivAuto==False:
        iv=base64.b64decode(input('\nIV:\n'))
        data=base64.b64decode(input('\nMensagem:\n'))
        cipher=AESGCM(key).encrypt(iv,data,None)
        print(f'\nCiphertext:\n{base64.b64encode(cipher).decode()}')
    else:

        iv=os.urandom(12)
        data=input('\nMensagem:\n').encode()
        cipher=AESGCM(key).encrypt(iv,data,None)
        data2=iv+cipher
        print('\nCiphertext:')
        print(base64.b64encode(data2).decode())

def decifrar(ivAuto):
    if ivAuto==False:
        iv=base64.b64decode(input('\nIV:\n'))
        data=base64.b64decode(input('\nCiphertext:\n'))
        cipher=AESGCM(key).decrypt(iv,data,None)
        print(f'\nMensagem:\n{base64.b64encode(cipher).decode()}')
    else:
        dataiv=base64.b64decode(input('\nCiphertext:\n'))
        iv=dataiv[:12]
        data=dataiv[12:]
        plaintext=AESGCM(key).decrypt(iv,data,None)
        print('\nMensagem:')
        print(plaintext.decode())
if __name__=="__main__":
    escolha3 = input('\nSomente use chave em base64 se souber o que está fazendo.\n(0) para chave em ascii, (1) para chave em base64:\n')
    key=input('\nChave:\n')
    if escolha3 == '1':
        key = base64.b64decode(key)
    else:
        key = key.encode()
    while len(key) < 32:
        key = key + b'\x00'
    print('\nSomente use IV manual se souber o que está fazendo.')
    escolha2=input('(0) para IV automático, (1) para IV manual:\n')
    if escolha2 == '1':
        print('\nAviso: TUDO está em base64.')
        ivAuto = False
    else:
        ivAuto = True
    while True:
        escolha=input('\n(0) para cifrar, (1) para decifrar.\nDigite "sair" para sair.\nDigite "clear" para limpar a tela.\n')
        if escolha == "clear":
            limp()
            continue
        elif escolha == "sair":
            exit()
        elif escolha=="1":
            decifrar(ivAuto)
        else:
            cifrar(ivAuto)
        print('\n' + '=' * 50)
