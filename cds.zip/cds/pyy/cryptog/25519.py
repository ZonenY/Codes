from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature
import base64



def bytes_obtainK(a):
    x = a.private_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PrivateFormat.Raw,
    encryption_algorithm=serialization.NoEncryption()
)
    return x
def bytes_obtainP(a):
    x = a.public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)
    return x
def undoK(a):
    return x25519.X25519PrivateKey.from_private_bytes(a)
def undoK_ed(a):
    return Ed25519PrivateKey.from_private_bytes(a)
def undoP(a):
    return x25519.X25519PublicKey.from_public_bytes(a)
def undoP_ed(a):
    return Ed25519PublicKey.from_public_bytes(a)

#funções ativas. use estas.
def x25519a():
    print('\n(O sistema inteiro está em base64.)')
    private_key = undoK(base64.b64decode(input('\nSecret key:\n')))
    public_key = private_key.public_key()
    print(f'\nPublic key:\n{base64.b64encode(bytes_obtainP(public_key)).decode()}\n')
    bb=input('Peer public key:\n')
    bb=undoP(base64.b64decode(bb))
    keey = private_key.exchange(bb)
    print(f'\nShared key:\n{base64.b64encode(keey).decode()}')
    print('\n' + '=' * 50)
    #Em Bytes
    return keey
#ass_verif=="ass" para assinar, "verif" para verificar
def ed25519a(ass_verif):
    print('\n(O sistema inteiro está em base64.)')
    if ass_verif == "ass":
        print('\n-----ASSINAR-----')
        sk = undoK_ed(base64.b64decode(input('\nSecret key:\n')))
        pk = sk.public_key()
        msg = input('\nMensagem:\n')
        sig = sk.sign(base64.b64decode(msg))
        print(f'\nPublic key:\n{base64.b64encode(bytes_obtainP(pk)).decode()}')
        print(f'\nAssinatura:\n{base64.b64encode(sig).decode()}')
    elif ass_verif=="verif":
        print('\n-----VERIFICAR-----')
        pk2=undoP_ed(base64.b64decode(input('\nPublic key:\n')))
        msg2=input('\nMensagem:\n')
        msg2=base64.b64decode(msg2)
        sig2=base64.b64decode(input('\nAssinatura:\n'))
        try:
            pk2.verify(sig2, msg2)
            print("\nResultado: assinatura valida.")
        except InvalidSignature:
            print("\nResultado: assinatura invalida.")
    print('\n' + '=' * 50)
if __name__=="__main__":
    while True:
        put=input('\n(0) para x25519, (1) para ed25519, (2) para sair\n')
        if put=="2":
            exit()
        elif put=="0":
            x25519a()
            continue
        put3=input('\n(0) para assinar, (1) para verificar\n')
        if put3=="0":
            ed25519a('ass')
        elif put3=="1":
            ed25519a('verif')
