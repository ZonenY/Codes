from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
import os
import base64

print('\n(Tudo em base64.)')
while True:
    # material inicial (Input Key Material)
    ikm=base64.b64decode(input('\nKey:\n'))

    # salt opcional mas fortemente recomendado
    salt=base64.b64decode(input('\nSalt:\n'))

    # separação de contexto
    info=base64.b64decode(input('\nInfo:\n'))

    # tamanho da chave derivada
    leen=int(input('\nTamanho da chave em bytes:\n'))

    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=leen,          
        salt=salt,
        info=info,
    )

    key = hkdf.derive(ikm)

    print(f'\nResultado:\n{base64.b64encode(key).decode()}')
    print('\n' + '=' * 50)
