#arquivo sub.txt substituira

import os

with open("sub.txt", "r", encoding="utf-8") as f:
    x = f.read()

with open("acc.txt", "w", encoding="utf-8") as f:
    f.write(x)

os.remove('sub.txt')
