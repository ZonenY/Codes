import os
import base64
import time
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
#usando versao 19 do argon2id

print('\n(Tudo em base64)')

def main():
    while True:
        passw=base64.b64decode(input('\nSenha:\n'))
        salt=base64.b64decode(input('\nSalt:\n'))
        leng=int(input('\nTamanho em bytes:\n'))
        iter2=int(input('\nIteracoes:\n'))
        paral=int(input('\nParalelismo:\n'))
        costt=int(input('\nMemory cost em KiB:\n'))


        kdf = Argon2id(
            salt=salt,
            length=leng,
            iterations=iter2,
            lanes=paral,
            memory_cost=costt,
        )

        start = time.perf_counter()

        key = kdf.derive(passw)

        end = time.perf_counter()

        key_b64 = base64.b64encode(key).decode()

        salt_b64 = base64.b64encode(salt).decode().rstrip('=')

        hash_b64 = base64.b64encode(key).decode().rstrip('=')

        argon2str = f'$argon2id$v=19$m={costt},t={iter2},p={paral}${salt_b64}${hash_b64}'

        print(f'\nHash base64:\n{key_b64}')

        print(f'\nFormato Argon2id:\n{argon2str}')

        print(f'\nTempo de calculo:\n{end - start:.6f} segundos')

        print('\n'+'=' * 50)
        
if __name__ == '__main__':
    main()
