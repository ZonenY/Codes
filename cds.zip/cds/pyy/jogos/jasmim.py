with open("palavrasforca.txt", encoding="utf-8") as arquivo:
    for linha in arquivo:
        w=linha.strip()
        if len(w)==5 and w[0]=='t' and w[4]=='o' and 'r' in w and 'e' in w and 'm' in w and w[1]!='r' and w[2]!='e' and w[2]!='m' and not any(c in w for c in ['a', 'i', 'u', 'b']):
            print(w)
