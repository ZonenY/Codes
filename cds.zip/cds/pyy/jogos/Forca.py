Nome="banana"
Dicas="peixe/cachorro/macaco/pedra"

import random
import string
import hashlib
import base64
import os
#Definições do jogo:

#Limpar tela:
def limp():
    os.system('cls' if os.name=='nt' else 'clear')
#Localizar elementos m em n
def loc(n,m):
    return [i for i,x in enumerate(n) if x==m]
#Inserir m, na string n, na posição p
def ins0(n,m,p):
    n=n[:p]+m+n[p:]
    return n
#(Função ad hoc. Define uma dica em Modos 2.), m=Nome, n=Lista C
def DiMod2(m,n):
    d3=""
    n=''.join(n)
    for i in range(3):
        L0=[L9 for L9 in string.ascii_lowercase if L9 not in (m+n+d3+"wyk")]
        L1=random.choice(L0)
        d3+=L1
    d3=list(d3)
    return f'[Dica: O Nome não tem as letras {d3}]'
#(Função ad hoc. Define um processo de derrota.)
def loss():
    limp()
    print("")
    print(E[6])
    print("")
    print(c)
    print(f'O nome era "{a}".')
    print("")
    print("[Game over!!!]")

#Funções do modo 3:
def bytes_obter(a):
    x=a.public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)
    return x
def undo_bytes(a):
    x=x25519.X25519PublicKey.from_public_bytes(a)
    return x
def falar(data,key):
    iv=os.urandom(12)
    data=data.encode()
    cipher=AESGCM(key).encrypt(iv,data,None)
    x=iv+cipher
    return base64.b64encode(x).decode()
def hear(data,key):
    x=base64.b64decode(data)
    iv=x[:12]
    data=x[12:]
    plain=AESGCM(key).decrypt(iv,data,None)
    return plain.decode()
def keyexchange():
    global key
    privkey=x25519.X25519PrivateKey.generate()
    pubkey=privkey.public_key()
    print(f'Digite "/sair" para sair do jogo.\nEnvie este código para o outro jogador:\n{base64.b64encode(bytes_obter(pubkey)).decode()}')
    codigo=str(input("\nCole aqui o código do outro jogador:\n"))
    if codigo=="/sair":
        exit()
    codigo=base64.b64decode(codigo)
    codigo=undo_bytes(codigo)
    key=privkey.exchange(codigo)
    key=hashlib.sha256(key).digest()

E=["-----\n |   |\n     |\n     |\n     |\n     |\n=========","-----\n |   |\n O   |\n     |\n     |\n     |\n=========","-----\n |   |\n O   |\n |   |\n     |\n     |\n=========","-----\n |   |\n O   |\n/|   |\n     |\n     |\n=========","-----\n |   |\n O   |\n/|\\  |\n     |\n     |\n=========","-----\n |   |\n O   |\n/|\\  |\n/    |\n     |\n=========","-----\n |   |\n O   |\n/|\\  |\n/ \\  |\n     |\n========="]
log="(0) Para Nome e Dicas padrão do jogo.\n(1) Para escolher Nome e Dicas.\n(2) Para Nome aleatório.\n(3) Para modo criptográfico (requer biblioteca cryptography)."
ent="Pressione enter para continuar..."
crptT=False

#Escolha de modo para o primeiro loop
print("")
print("Escolha o modo:")
print(log)
Modos=str(input("\nModo:\n"))
if Modos not in ("0","1","2","3"):
    print("")
    input("[Nenhum modo válido foi escolhido. Modo foi definido para 0.]")
    Modos="0"

#Loop do jogo
while True:
    #di=contador de dicas usadas, k=contador de erros, C=contador de letras usadas, md2 legenda do modo 2
    di,k,C,md2=0,0,[],""
    print("")
    if Modos=="1":
        print("[Não deixe que o outro jogador veja.]")
        print("[Cada detalhe importa no Nome: símbolos, acentos, espaço e letras maiúsculas.]")
        print("[Não deixe o Nome vazio.]")
        print('[Não ponha "*" em nenhum lugar no Nome.]')
        print("")
        Nome=str(input("Escolha o Nome:\n"))
        if "*" in Nome:
            Nome=Nome.replace("*","")
        if Nome=="":
            Nome=" "
        print("")
        print("[Ponha quantas dicas quiser.]")
        print('[Coloque Dicas:Dica1/Dica2/Dica3... usando "/" como separador.]')
        print("[Se quiser colocar apenas uma dica, deixe Dicas:Dica1]")
        print("[Se não quiser colocar nenhuma dica, deixe vazio.]")
        print("")
        Dicas=str(input("Dicas:\n"))
    elif Modos=="2":
        with open("palavrasforca.txt", encoding="utf-8") as arquivo:
            palavra = None
            for i, linha in enumerate(arquivo, 1):
                if random.randrange(i)==0:
                    palavra = linha.strip()
        Nome = palavra.lower()
        md2="[Palavra aleatória da língua portuguesa. Todas têm letra minúscula. Apenas palavras de a-z, sem acentos nem símbolos.]"
        print("[Você tem entre 0 até 3 dicas.]")
        d2=str(input("Escolha quantas dicas você quer.\nPressione enter para 0 dicas:\n"))
        Dicas=""
        if d2 in ("1", "2", "3"):
            d2=int(d2)
        else:
            d2=0
        if d2>=1:
            Dicas+=" "
        if d2>=2:
            Dicas+=f'/O nome começa com "{Nome[0]}".'
        if d2>=3:
            Dicas+=f'/O nome termina com "{Nome[-1]}".'
    elif Modos=="3":
        from cryptography.hazmat.primitives.asymmetric import x25519
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        if crptT==True:
            crptt=str(input('Digite "/des" para desconectar do jogador atual.\nDigite "/sair" para sair do jogo.\nDigite qualquer outra coisa para continuar:\n'))
            if crptt=="/des":
                print("")
                keyexchange()
            elif crptt=="/sair":
                exit()
        else:
            keyexchange()
        crptT=True
        verif=str(input('\nDigite "1" se você quer ser o nomeador. Digite qualquer coisa para ser adivinhador.\n'))
        if verif=="1":
            print("\n[Cada detalhe importa no Nome: símbolos, acentos, espaço e letras maiúsculas.]")
            print("[Não deixe o Nome vazio.]")
            print('[Não ponha "*" em nenhum lugar no Nome.]')
            print("")
            Nome=str(input("Escolha o Nome:\n"))
            if "*" in Nome:
                Nome=Nome.replace("*","")
            if Nome=="":
                Nome=" "
            print("")
            print("[Ponha quantas dicas quiser.]")
            print('[Coloque Dicas:Dica1/Dica2/Dica3... usando "/" como separador.]')
            print("[Se quiser colocar apenas uma dica, deixe Dicas:Dica1]")
            print("[Se não quiser colocar nenhuma dica, deixe vazio.]")
            print("")
            Dicas=str(input("Dicas:\n"))
            nomedica=f'{Nome}*{Dicas}'
            nomedica=falar(nomedica,key)
            print(f'\nEnvie este código para o adivinhador:\n\n{nomedica}\n')
            input(ent)
            while True:
                print('\nEspere o jogador enviar o código para verificar o estado atual da partida.\nDigite "/quit" para desconectar da partida.\nDigite "/sair" para sair do jogo.')
                state=str(input('\nCole aqui o código:\n'))
                if state=="/quit":
                    break
                elif state=="/sair":
                    exit()
                else:
                    limp()
                    print(hear(state,key))
            continue
        else:
            print('Espere o nomeador enviar o código para ser definido o Nome e as Dicas.')
            verif2=str(input('Cole aqui o código:\n'))
            nomedica=hear(verif2,key)
            asterisc=loc(nomedica,"*")
            Nome=nomedica[:asterisc[0]]
            Dicas=nomedica[asterisc[0]+1:]
    #c=tabela de letras certas, B=conjunto de dicas
    a=Nome
    cc=['*']*len(a)
    c=ins0('()',''.join(cc),1)
    B=Dicas.split("/") if Dicas!="" else []
    if Modos=="3":
        md2='Digite "/share" para compartilhar o estadoa tual da partida com o nomeador.'
    rules='[Digite "/dicas" para obter dicas.]\n[Digite "/sair" para sair.]\n[Digite "/desistir" para desistir.]\n[Se você colocar mais de uma letra, apenas a primeira será contada.]\n[Tente adivinhar o Nome antes que chegue em 6/6 tentativas.]\n[Você tem {} dica(s).]\n{}'.format(len(B),md2)

    #Loop da partida
    while True:
        limp()
        print(f"{rules}")
        print(E[k])
        print("")
        print("Nome:",c)
        print("Letras que já foram: "+f"{C}")
        print(f"[{k}/6 tentativas.]")
        print("")
        b=str(input("Palpite:\n"))
        print("")
        rules=""
        if b=="":
            print("[Você esqueceu de colocar o palpite.]")
            input(ent)
            continue
        elif b[0]=="/":
            if b=="/":
                pass
            elif b=="/dicas":
                if Modos=="2":
                    if di==0 and len(B)>0:
                        print(DiMod2(a,C))
                        input(ent)
                        di+=1
                        continue
                if Dicas=="":
                    print("[Não há dicas.]")
                    input(ent)
                elif di==len(B):
                    print("[Não há mais dicas.]")
                    input(ent)
                else:
                    print(f"[Dica: {B[di]}]")
                    input(ent)
                    di+=1
                continue
            elif b=="/desistir":
                print("[Derrota.]")
                input(ent)
                loss()
                break
            elif b=="/sair":
                exit()
            elif b=="/share" and Modos=="3":
                share=f'{E[k]}\n\nNome: {c}\nLetras que já foram: {C}\nDicas usadas: {di}/{len(B)}\n[{k}/6 tentativas.]'
                share=falar(share,key)
                print(f'Compartilhe este código com o nomeador:\n\n{share}\n')
                input(ent)
                continue
            else:
                print("[Comando inválido.]")
                input(ent)
                continue
        b=b[0]
        if b in C:
            print("[Essa letra já foi.]")
            input(ent)
            continue
        C+=[b]
        if b not in a:
            print("[Errou. ❌️]")
            input(ent)
            k+=1
        else:
            for i in loc(a,b):
                cc[i]=b
            c=ins0('()',''.join(cc),1)
            print("[Acertou. ✅️]")
            input(ent)
        #Condições de vitória/derrota
        k1=c[1:-1]
        if k==6:
            loss()
            break
        elif k1==a:
            print("")
            print("O nome era:",c)
            print("")
            print("[Vitória!!!]")
            break
    #Partida acabou
    print("")
    print("[Pressione enter para recomeçar...]")
    print('[Digite "/modos (x)" para escolher novo modo.]')
    print(f"[{log}]")
    print('[Digite "/sair" para finalizar...]')
    r=str(input(""))
    if len(r)==8:
        if r[7] in ("0","1","2","3") and r==f"/modos {r[7]}":
            Modos=str(r[7])
            print("")
            print(f"[Alterado para modo {Modos}.]")
            input(ent)
    elif r=="/sair":
        exit()
    limp()
