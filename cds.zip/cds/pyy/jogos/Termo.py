import random
import string
import os
def limp():
    os.system('cls' if os.name=='nt' else 'clear')
#função ad hoc
def aaa(nome,palpite,c):
    dic={i:0 for i in nome}
    for i in range(5):
        if palpite[i]==nome[i]:
            dic[palpite[i]]+=1
    for i in range(5):
        if palpite[i]==nome[i]:
            c+="✅"
        elif palpite[i] in nome and dic[palpite[i]]<nome.count(palpite[i]):
            c+="⚠️"
            dic[palpite[i]]+=1
        else:
            c+="❌"
    return c
ent="Pressione enter para continuar..."
chaves=["c","c2","c3","c4"]



while True:
    print("\nDigite:\n(1) Para termo.\n(2) Para dueto.\n(3) Para quarteto.")
    Modos=str(input("\nEscolha o modo:\n"))
    if Modos not in ("1","2","3"):
        Modos="1"
    Modos=int(Modos)
    if Modos==1:
        wa=1
        tentativas=6
    elif Modos==2:
        wa=2
        tentativas=7
    elif Modos==3:
        wa=4
        tentativas=9
    dicC={}
    for i in range(wa):
        with open("palavrasforca.txt", encoding="utf-8") as arquivo:
            palavra=None
            k=0
            for linha in arquivo:
                w=linha.strip()
                if len(w)==5:
                    k+=1
                    if random.randrange(k)==0:
                        palavra=w
            #dicC{key:[tabela,condição de vitória,palavra]}
            dicC[chaves[i]]=["",True,palavra.lower()]
    a=[]
    for i in dicC:
        a+=[dicC[i][2]]
    k,L1=0,[]
    print(f'\nRegras:\nTente adivinhar tudo antes de atingir {tentativas}/{tentativas} tentativas.\nSão aceitas apenas palavras formadas por letras minúsculas de "a" a "z", sem acentos nem símbolos.\nDigite "/desistir" para desistir\nDigite "/sair" para sair.')
    while True:
        T1,Tr=False,False
        for i in dicC:
            dicC[i][0]=""
        b=str(input("\n\n-----Palpite:"))
        if b=="":
            print("[Você esqueceu de colocar o palpite.]")
            input(ent)
            continue
        elif b=="/desistir":
            print(f'\n[Derrota.]\nAs palavras eram: {a}' if Modos!=1 else f'\n[Derrota.]\nA palavra era: "{a[0]}"')
            break
        elif b=="/sair":
            exit()
        elif len(b)!=5:
            print("[Erro. Palpite não tem 5 letras.]")
            input(ent)
            continue
        for i in b:
            if i not in string.ascii_lowercase:
                T1=True
        if T1==True:
            print("[Erro. Palpite com letras inválidas]")
            input(ent)
            continue
        with open('palavrasforca.txt',encoding='utf-8') as arq:
            if any(linha.rstrip('\n')==b for linha in arq):
                Tr=True
        if Tr==False:
            print("[Essa palavra não é aceita.]")
            input(ent)
            continue

        for i in dicC:
            if dicC[i][1]==True:
                dicC[i][0]=aaa(dicC[i][2],b,dicC[i][0])
            else:
                dicC[i][0]="✅️✅️✅️✅️✅️"
        print(f"Resposta (1):{dicC["c"][0]}")
        if Modos==2 or Modos==3:
            print(f"Resposta (2):{dicC["c2"][0]}")
        if Modos==3:
            print(f"Resposta (3):{dicC["c3"][0]}")
            print(f"Resposta (4):{dicC["c4"][0]}")

        L2=[]
        for i in b:
            L1+=[i]
        for i in L1:
            if i not in L2:
                L2+=[i]
        L2.sort()
        L1=L2
        print(f"Letras que já foram: [{''.join(L1)}]")

        k+=1
        print(f"{k}/{tentativas} tentativas")
        for i in dicC:
            if b==dicC[i][2]:
                dicC[i][1]=False
        if not any(dicC[i][1] for i in dicC):
            print("\n[Vitória!!!]")
            break
        elif k==tentativas:
            print(f'\n[Derrota.]\nAs palavras eram: {a}' if Modos!=1 else f'\n[Derrota.]\nA palavra era: "{a[0]}"')
            break

    print('\n[Game Over.]\n[Digite "/sair" para sair.]')
    qaz=input(ent)
    if qaz=="/sair":
        exit()
    limp()
