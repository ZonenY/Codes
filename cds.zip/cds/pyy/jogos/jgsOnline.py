import socket
import os
import random
HOST = '0.0.0.0'
PORT = 5000
#Definições:

#Limpar tela:
def limp():
    os.system('cls' if os.name=='nt' else 'clear')
#Localizar elementos m em n
def loc(n,m):
    return [i for i,x in enumerate(n) if x==m]
#Inserir m, na string n, na posição p
def ins0(n,m,p):
    n=n[:p]+m+n[p:]
    return n
#(Função ad hoc. Define um processo de derrota.)
def loss(conn,E,c,a):
    limp()
    t25=f'\n{E[6]}\n\n{c}\nO nome era "{a}".\n\n[Game over!!!]'
    print(t25)
    conn.sendall(t25.encode('utf-8'))

E=["-----\n |   |\n     |\n     |\n     |\n     |\n=========","-----\n |   |\n O   |\n     |\n     |\n     |\n=========","-----\n |   |\n O   |\n |   |\n     |\n     |\n=========","-----\n |   |\n O   |\n/|   |\n     |\n     |\n=========","-----\n |   |\n O   |\n/|\\  |\n     |\n     |\n=========","-----\n |   |\n O   |\n/|\\  |\n/    |\n     |\n=========","-----\n |   |\n O   |\n/|\\  |\n/ \\  |\n     |\n========="]
ent="Pressione enter para continuar..."
esp="Esperando o jogador confirmar..."
ordem = {'!': 0, '#': 1, '-': 2}

#--------------

def ForcaS(conn):
    global E
    global ent
    global esp
    conn.sendall(b'\x00')
    print("[Cada detalhe importa no Nome: símbolos, acentos, espaço e letras maiúsculas.]")
    print("[Não deixe o Nome vazio.]")
    print('[Não ponha "*" em nenhum lugar no Nome.]')
    print("")
    Nome=str(input("Escolha o Nome:\n"))
    if "*" in Nome:
        Nome=Nome.replace("*","")
    if Nome=="":
        Nome="a"
    conn.sendall(b'\xf2jqwf8h1379fg1fas')
    print("")
    print("[Ponha quantas dicas quiser.]")
    print('[Coloque Dicas:Dica1/Dica2/Dica3... usando "/" como separador.]')
    print("[Se quiser colocar apenas uma dica, deixe Dicas:Dica1]")
    print("[Se não quiser colocar nenhuma dica, deixe vazio.]")
    print("")
    Dicas=str(input("Dicas:\n"))
    conn.sendall(b'\xf2jqwf8h1379fg1fas')
    #Jogo
    #di=contador de dicas usadas, k=contador de erros, C=contador de letras usadas
    di,k,C=0,0,[]
    print("")
    #c=tabela de letras certas, B=conjunto de dicas
    a=Nome
    cc=['*']*len(a)
    c=ins0('()',''.join(cc),1)
    B=Dicas.split("/") if Dicas!="" else []
    rules='[Digite "/dicas" para obter dicas.]\n[Digite "/sair para sair do modo online."]\n[Digite "/desistir" para desistir.]\n[Se você colocar mais de uma letra, apenas a primeira será contada.]\n[Tente adivinhar o Nome antes que chegue em 6/6 tentativas.]\n[Você tem {} dica(s).]'.format(len(B))

    #Loop da partida | \x10 é input palpit \x11 é limpar tela \x12 é input confirmar
    while True:
        conn.sendall(b'\x11')
        limp()
        t22=f'{rules}\n{E[k]}\n\nNome: {c}\nLetras que já foram: {C}\n[{k}/6 tentativas.]'
        print(t22)
        conn.sendall(t22.encode('utf-8'))
        conn.sendall(b'\x10')
        print("Esperando palpite do jogador...")
        b=conn.recv(1024).decode()
        print(f"Palpite:{b}")
        print("")
        rules=""
        if b[0]=="/":
            if b=="/":
                pass
            elif b=="/dicas":
                if Dicas=="":
                    conn.sendall('\n[Não há dicas.]\n'.encode('utf-8'))
                    conn.sendall(b'\x12')
                    print("[Não há dicas.]\n")
                    print(esp)
                    conn.recv(1024)
                elif di==len(B):
                    conn.sendall('\n[Não há mais dicas.]\n'.encode('utf-8'))
                    conn.sendall(b'\x12')
                    print("[Não há mais dicas.]\n")
                    print(esp)
                    conn.recv(1024)
                else:
                    t27=f"[Dica: {B[di]}]\n"
                    conn.sendall(b'\n'+t27.encode('utf-8'))
                    conn.sendall(b'\x12')
                    print(t27)
                    print(esp)
                    conn.recv(1024)
                    di+=1
                continue
            elif b=="/desistir":
                conn.sendall(b'\n[Derrota.]\n')
                conn.sendall(b'\x12')
                print("[Derrota.]\n")
                print(esp)
                conn.recv(1024)
                loss(conn,E,c,a)
                break
            else:
                conn.sendall('\n[Comando inválido.]\n'.encode('utf-8'))
                conn.sendall(b'\x12')
                print("[Comando inválido.]\n")
                print(esp)
                conn.recv(1024)
                continue
        b=b[0]
        if b in C:
            conn.sendall('\n[Essa letra já foi.]\n'.encode('utf-8'))
            conn.sendall(b'\x12')
            print("[Essa letra já foi.]\n")
            print(esp)
            conn.recv(1024)
            continue
        C+=[b]
        if b not in a:
            conn.sendall('\n[Errou. ❌️]\n'.encode('utf-8'))
            conn.sendall(b'\x12')
            print("[Errou. ❌️]\n")
            print(esp)
            conn.recv(1024)
            k+=1
        else:
            for i in loc(a,b):
                cc[i]=b
            c=ins0('()',''.join(cc),1)
            conn.sendall('\n[Acertou. ✅️]\n'.encode('utf-8'))
            conn.sendall(b'\x12')
            print("[Acertou. ✅️]\n")
            print(esp)
            conn.recv(1024)
        #Condições de vitória/derrota
        k1=c[1:-1]
        if k==6:
            loss(conn,E,c,a)
            break
        elif k1==a:
            t29=f"\nO nome era: {c}\n[Vitória!!!]"
            conn.sendall(t29.encode('utf-8'))
            print(t29)
            break
    #Partida acabou
    conn.sendall(b'\x13')
    print("")
    input("[Pressione enter para voltar pro Lobby...]")
    limp()
    print('Escolha o modo de jogo: (1) para forca, (2) para senha.\nDigite "/ren" para renunciar o host.\nDigite "/sair" para sair do modo online.\nDigite qualquer outra coisa para falar no chat.\n')
    conn.sendall(b'\xf2jqwf8h1379fg1fas')



def ForcaC(s):
    global ent
    print('\nForca escolhido!')
    print('\nEsperando o host escolher o Nome...')
    s.recv(1024)
    print('\nEsperando o host escolher as Dicas...')
    s.recv(1024)
    print(f'\nJogo começou! {ent}')
    while True:
        r24=s.recv(1024)
        if r24==b'\x10':
            r25=str(input('Palpite:'))
            if r25=="":
                r25=" "
            elif r25=="/sair":
                exit()
            s.sendall(r25.encode('utf-8'))
        elif r24==b'\x11':
            limp()
        elif r24==b'\x12':
            input(ent)
            s.sendall(b'\xf2jqwf8h1379fg1fas')
        elif r24==b'\x13':
            break
        else:
            print(r24.decode())
    print('[A partida acabou.]\nEsperando host confirmar...')
    s.recv(1024)
    limp()
    print("Esperando resposta do host...\n")


#-----------------------------------------------------------

def MasterS(conn):
    global ordem
    conn.sendall(b'\x01')
    Nome="1234"
    while True:
        TT=False
        print("[Coloque a Resposta somente como números de 1 até 6.]")
        print("[Não deixe a Resposta vazia.]")
        print('[A resposta deve ter exatamente quatro dígitos.]\n')
        Nome=str(input("Escolha a Resposta:"))
        if Nome=="":
            print("[Resposta inválida.]\n")
            continue
        elif len(Nome)!=4:
            print("[Resposta inválida.]\n")
            continue
        for i in range(4):
            if Nome[i] not in ("1","2","3","4","5","6"):
                TT=True
        if TT==True:
            print("[Resposta inválida.]\n")
            continue
        break
    conn.sendall(b'\xf2jqwf8h1379fg1fas')
    a=Nome
    k=0
    tr=str(input("Escolha quantas tentativas você quer. De 7 até 10 tentativas:"))
    if tr not in ("7","8","9","10"):
        tr="10"
    conn.sendall(b'\xf2jqwf8h1379fg1fas')
    limp()
    print(f'\nRegras:\nColoque um palpite com quatro números de 1 até 6.\nSe o resultado der "!" significa que você acertou uma posição e um número corretamente.\nSe o resultado der "#" significa que você acertou apenas um número.\nSe o resultado der "-" significa que errou ambos.\nVocê vence se acertar todas as posições e números corretamente. Perde se chegar em {tr}/{tr} tentativas.\nDigite "/desistir" para desistir.\nDigite "/sair" para sair do modo online.\n')
    conn.sendall(f'\nRegras:\nColoque um palpite com quatro números de 1 até 6.\nSe o resultado der "!" significa que você acertou uma posição e um número corretamente.\nSe o resultado der "#" significa que você acertou apenas um número.\nSe o resultado der "-" significa que errou ambos.\nVocê vence se acertar todas as posições e números corretamente. Perde se chegar em {tr}/{tr} tentativas.\nDigite "/desistir" para desistir.\nDigite "/sair" para sair do modo online.\n'.encode('utf-8'))
    while True:
        print("Esperando o jogador dar o palpite...")
        print("")
        c=""
        conn.sendall(b'\x10')
        b=conn.recv(1024).decode()
        if b=="/desistir":
            print(f'\n[Derrota.]\nA resposta era: ({a})\n[Game over!!!]')
            conn.sendall(f'\n[Derrota.]\nA resposta era: ({a})\n[Game over!!!]'.encode('utf-8'))
            break

        dic = {i:0 for i in a}
        for i in range(4):
            if b[i] == a[i]:
                dic[b[i]] += 1
        for i in range(4):
            if a[i] == b[i]:
                c += '!'
            elif b[i] in a and dic[b[i]] < a.count(b[i]):
                c += '#'
                dic[b[i]] += 1
            else:
                c += '-'
        c = ''.join(sorted(c, key=lambda s: ordem[s]))

        print(f'Resultado: ({c})\n{k+1}/{tr} tentativas.')
        conn.sendall(f'Resultado: ({c})\n{k+1}/{tr} tentativas.'.encode('utf-8'))
        k+=1
        if c=="!!!!":
            print("[Vitória!!!]")
            conn.sendall('[Vitoria!!!]'.encode('utf-8'))
            break
        elif k==int(tr):
            print(f'A resposta era: ({a})\n[Game over!!!]')
            conn.sendall(f'A resposta era: ({a})[Game over!!!]'.encode('utf-8'))
            break
    #Fim da partida
    conn.sendall(b'\x13')
    print("")
    input("[Pressione enter para voltar pro Lobby...]")
    limp()
    print('Escolha o modo de jogo: (1) para forca, (2) para senha.\nDigite "/ren" para renunciar o host.\nDigite "/sair" para sair do modo online.\nDigite qualquer outra coisa para falar no chat.\n')
    conn.sendall(b'\xf2jqwf8h1379fg1fas')



def MasterC(s):
    global ent
    print('\nSenha escolhido!')
    print('\nEsperando o host escolher a Resposta...')
    s.recv(1024)
    print('\nEsperando o host escolher as tentativas...')
    s.recv(1024)
    print('\nJogo começou!')
    while True:
        r24=s.recv(1024)
        if r24==b'\x10':
            TT1=False
            while True:
                TT2=False
                print("")
                r25=str(input('Palpite:'))
                if r25=="/desistir":
                    s.sendall(b"/desistir")
                    TT1=True
                    break
                elif r25=="":
                    print("[Você esqueceu de colocar o palpite.]")
                    input(ent)
                    continue
                elif r25=="/sair":
                    exit()
                elif len(r25)!=4:
                    print("[Erro. O palpite deve ter 4 números.]")
                    input(ent)
                    continue
                for i in range(4):
                    if r25[i] not in ("1","2","3","4","5","6"):
                        TT2=True
                if TT2==True:
                    print("[Erro. Palpite inválido.]")
                    input(ent)
                    continue
                break
            if TT1==False:
                s.sendall(r25.encode('utf-8'))
        elif r24==b'\x13':
            break
        else:
            print(r24.decode())
    print('\n[A partida acabou.]\nEsperando host confirmar...')
    s.recv(1024)
    limp()
    print("Esperando resposta do host...\n")

#--------------------

def servidor():
    print("\nAguardando conexão...")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        conn, addr = s.accept()
        with conn:
            print(f'\nConectado por:\n{addr}')
            print('\nEscolha o modo de jogo:\n(1) Para forca.\n(2) Para senha.\nDigite "/ren" para renunciar o host.\nDigite "/sair" para sair do modo online.\nDigite qualquer outra coisa para falar no chat.')
            while True:
                r22=str(input('\nEnviar resposta:\n'))
                if r22=="1" or r22=="2":
                    limp()
                if r22=="1":
                    ForcaS(conn)
                elif r22=="2":
                    MasterS(conn)
                elif r22=="/ren":
                    conn.sendall(b'\xf4')
                    break
                elif r22=="/sair":
                    conn.sendall(b'\xf5')
                    exit()
                else:
                    conn.sendall(r22.encode())
                    print(f'\nResposta (cliente):\n{conn.recv(1024).decode()}')

def cliente():
    host = input("\nIP do servidor:\n")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, PORT))
        print("\nConectado!")
        print("\nEsperando resposta do host...")
        while True:
            r23=s.recv(1024)
            if r23==b'\x00':
                ForcaC(s)
            elif r23==b'\x01':
                MasterC(s)
            elif r23==b'\xf4':
                print("\nHost renunciou o cargo.")
                break
            elif r23==b'\xf5':
                print("\nHost saiu.")
                break
            else:
                print(f'\nResposta (servidor):\n{r23.decode()}')
                r99=str(input('\nEnviar resposta:\n'))
                s.sendall(r99.encode())

while True:
    modo = input('\nServidor (s) ou Cliente (c)?\nDigite "/sair" para sair.\n')
    if modo=='c':
        cliente()
    elif modo=='s':
        servidor()
    elif modo=="/sair":
        exit()
    else:
        print('[Nenhuma opção foi escolhida.]')
        cliente()
