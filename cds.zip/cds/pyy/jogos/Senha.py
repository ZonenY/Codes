import random
import os
def limp():
    os.system('cls' if os.name=='nt' else 'clear')
ent="Pressione enter para continuar..."
ordem = {'!': 0, '#': 1, '-': 2}
print("\nModos:\n(0) Para resposta padrão.\n(1) Para escolher resposta.\n(2) Para resposta aleatória.")
Modos=str(input("\nEscolha o modo:\n"))
if Modos not in ("0", "1", "2"):
    print("\nNenhum modo válido foi escolhido. Modo foi definido para 0.")
    Modos = '0'
while True:
    siz = input('\nEscolha o tamanho da resposta. De 4 até 8:\n')
    if siz not in ('4', '5', '6', '7', '8'):
        print('\nNenhum tamanho válido foi escolhido. O tamanho foi definido para 4.')
        siz = 4
    siz = int(siz)
    if Modos=="0":
        Nome = '1'*siz
        pass
    elif Modos=="1":
        print("[Não deixe que outra pessoa veja.]")
        while True:
            TM = False
            print("\nPonha a Resposta.")
            print(f"A Resposta deve ter {siz} dígitos, com números somente de 1 até 6.")
            Nome=str(input("Resposta:\n"))
            if Nome=="":
                print('[Resposta inválida.]\n')
                continue
            elif len(Nome) != siz:
                print('[Resposta inválida.]\n')
                continue
            for i in range(siz):
                if Nome[i] not in ("1","2","3","4","5","6"):
                    print('[Resposta inválida.]')
                    TM = True
                    break
            if TM:
                continue
            print("")
            break
    elif Modos=="2":
        Nome=""
        for i in range(siz):
            r=str(random.randint(1,6))
            Nome+=f"{r}"
    tr=str(input("\nEscolha quantas tentativas você quer.\nDe 1 até 10 tentativas:\n"))
    if tr not in ("1","2","3","4","5","6","7","8","9","10"):
        tr="10"
    a=Nome
    k=0
    limp()
    print(f'\nRegras:\nColoque um palpite com {siz} números de 1 até 6.\nSe o resultado der "!" quer dizer que você acertou uma posição e um número corretamente.\nSe o resultado der "#" significa que você acertou apenas um número.\nSe o resultado der "-" significa que errou ambos.\nVocê vence se acertar todas as posições e números corretamente. Perde se chegar em {tr}/{tr} tentativas.\nDigite "/desistir" para desistir.\nDigite "/sair" para sair do jogo.')
    while True:
        c, TN = "", False
        b=str(input("\nPalpite:"))
        if b=="":
            print("[Você esqueceu de colocar o palpite.]")
            input(ent)
            continue
        if b=="/sair":
            exit()
        if b=="/desistir":
            print("\n[Derrota.]")
            print(f'\nA resposta era: ({a})')
            print("[Game over!!!]")
            break
        if len(b) != siz:
            print(f"[Erro. O palpite deve ter {siz} números.]")
            input(ent)
            continue

        dic = {i:0 for i in a}
        for i in range(siz):
            if b[i] == a[i]:
                dic[b[i]] += 1
            elif b[i] not in ("1","2","3","4","5","6"):
                print("[Erro. Palpite com números inválidos.]")
                input(ent)
                TN = True
                break
        if TN:
            continue
        for i in range(siz):
            if a[i] == b[i]:
                c += '!'
            elif b[i] in a and dic[b[i]] < a.count(b[i]):
                c += '#'
                dic[b[i]] += 1
            else:
                c += '-'
        c = ''.join(sorted(c, key=lambda s: ordem[s]))

        print(f"Resultado: ({c})")
        print(f"{k+1}/{tr} tentativas.")
        k += 1
        if c == '!'*siz:
            print("\n[Vitória!!!]")
            break
        if k==int(tr):
            print(f'\nA Resposta era: ({a})')
            print("[Game over!!!]")
            break
    print('\nA partida acabou.\nDigite "/modos (x)" para escolher novo modo.\nModos: 0 para resposta padrão, 1 para escolher resposta, 2 para resposta aleatória.\nDigite "/sair" para sair.')
    r=str(input(""))
    if len(r)==8:
        if r[7] in ("0","1","2") and r==f"/modos {r[7]}":
            Modos=str(r[7])
            print("")
            print(f"[Alterado para modo {Modos}.]")
            input(ent)
    elif r=="/sair":
        exit()
    limp()
