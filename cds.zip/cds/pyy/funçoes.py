#Localizar elementos m em n
def loc(n,m):
    return [i for i,x in enumerate(n) if x==m]
#Inserir m, na string n, na posição p
def ins0(n,m,p):
    n=n[:p]+m+n[p:]
    return n
#Tabela n, inserir m, referência p, separador q
def insTitle(n,m,p,q):
    a=loc(p,m)
    n=list(n)
    for i in range(len(a)):
        n.insert(loc(n,q)[a[i]] if a[i]!=len(p)-1 else loc(n,q)[-1]+1,m)
    return ''.join(n)
#h: função da variação de dias dos meses gregorianos, n: mês, a: ano
def h(n,a):
    if n==2:
        return 1 if a%4==0 and (a%100!=0 or a%400==0) else 0
    elif n%2==0 and n<=7:
        return 2
    elif n%2==1 and n<=7:
        return 3
    elif n%2==0 and n>=8:
        return 3
    else:
        return 2
#calc: calculador de dia da semana, requer h(n,a). a: ano, b: mês, c: dia
def calc(a,b,c):
    w=a-2026
    d,e,f,g=int(w/4),c%7,w%7,int((a-2000+(-1 if w>=0 else 1))/100)-int((a-2000+(-1 if w>=0 else 1))/400)
    x=d+e+f-g
    if w>=0 and w%4==3:
        x+=1
    elif w<0 and (w%4 in (1,2)):
        x=x-1+(1 if a%100==0 and a%400!=0 else 0)
    for i in range(b-1):
        x+=h(i+1,a)
    x%=7
    return x
#zeller0: função do algorítmo de zeller
def zeller0(ano, mes, dia):
    if mes <= 2:
        mes += 12
        ano -= 1

    K = ano % 100
    J = ano // 100

    h = (dia + (13*(mes+1))//5 + K + K//4 + J//4 + 5*J) % 7

    dias = [
        "Sábado",
        "Domingo",
        "Segunda-feira",
        "Terça-feira",
        "Quarta-feira",
        "Quinta-feira",
        "Sexta-feira"
    ]

    return dias[h]
#troca de chaves criptográfica
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import hashlib
import base64
import os
def bytes_obter(a):
    x=a.public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)
    return x
def undo_bytes(a):
    x=x25519.X25519PublicKey.from_public_bytes(a)
    return x
def falar(data,key):
    iv=os.urandom(12)
    data=data.encode()
    cipher=AESGCM(key).encrypt(iv,data,None)
    x=iv+cipher
    return base64.b64encode(x).decode()
def hear(data,key):
    x=base64.b64decode(data)
    iv=x[:12]
    data=x[12:]
    plain=AESGCM(key).decrypt(iv,data,None)
    return plain.decode()
def keyexchan():
    privkey=x25519.X25519PrivateKey.generate()
    pubkey=privkey.public_key()
    print(f'Código:\n\n{base64.b64encode(bytes_obter(pubkey)).decode()}')
    codigo=str(input("\nColar código:"))
    codigo=base64.b64decode(codigo)
    codigo=undo_bytes(codigo)
    key=privkey.exchange(codigo)
    key=hashlib.sha256(key).digest()
    return key
