import secrets

while True:
    try:
        b = input('\nPonha os itens para escolher aleatoriamente:\n')
        b = b.split(' ')
        c = int(input('\nNúmero de dados:\n'))

        if b == '':
            print('Ponha alguma coisa.')
            continue

        elif c < 0:
            print('O número de dados não pode ser negativo.')
            continue

        for i in range(c):
            numero = secrets.randbelow(len(b))
            choice = b[numero]
            print(f'\nEscolha aleatoria ({i+1}):\n{choice}')

    except ValueError:
        print('Digite apenas números inteiros.')
    print('\nItens:',len(b))
    print('\n' + '='*50)
