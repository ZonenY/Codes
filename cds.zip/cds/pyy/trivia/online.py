import socket
import random

HOST = '0.0.0.0'
PORT = 5000

def servidor():
    print("Aguardando conexão...")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        conn, addr = s.accept()
        with conn:
            print("Conectado por", addr)

def cliente():
    host = input("IP do servidor: ")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, PORT))
        print("Conectado!")

if __name__ == "__main__":
    while True:
        modo = input('Servidor (s) ou Cliente (c)?\nDigite "/sair" para sair.\n')
        if modo=='s':
            servidor()
        elif modo=="/sair":
            exit()
        else:
            cliente()
