from kivy.app import App
from kivy.uix.button import Button

class MyApp(App):
    def build(self):
        btn = Button(text="AUTOCLICK")
        btn.bind(on_press=self.toggle)
        return btn

    def toggle(self, *args):
        print("ativado")

MyApp().run()
