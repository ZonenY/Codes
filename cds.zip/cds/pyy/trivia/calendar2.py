def zeller0(ano, mes, dia):
    if mes <= 2:
        mes += 12
        ano -= 1

    K = ano % 100
    J = ano // 100

    h = (dia + (13*(mes+1))//5 + K + K//4 + J//4 + 5*J) % 7

    dias = [
        "Sábado",
        "Domingo",
        "Segunda-feira",
        "Terça-feira",
        "Quarta-feira",
        "Quinta-feira",
        "Sexta-feira"
    ]

    return dias[h]

Dias0=["Quarta-feira","Quinta-feira","Sexta-feira","Sábado","Domingo","Segunda-feira","Terça-feira"]
def h(n,a):
    if n==2:
        return 1 if a%4==0 and (a%100!=0 or a%400==0) else 0
    elif n%2==0 and n<=7:
        return 2
    elif n%2==1 and n<=7:
        return 3
    elif n%2==0 and n>=8:
        return 3
    else:
        return 2
def calc(a,b,c):
    w=a-2026
    d,e,f,g=int(w/4),c%7,w%7,int((a-2000+(-1 if w>=0 else 1))/100)-int((a-2000+(-1 if w>=0 else 1))/400)
    x=d+e+f-g
    if w>=0 and w%4==3:
        x+=1
    elif w<0 and (w%4 in (1,2)):
        x=x-1+(1 if a%100==0 and a%400!=0 else 0)
    for i in range(b-1):
        x+=h(i+1,a)
    x%=7
    return x
j1,j2,j3=0,0,0
#Mude esta linha (True/False) para teste.
while False:
    if Dias0[calc(j1,j2+1,j3+1)]==zeller0(j1,j2+1,j3+1):
        print("")
    else:
        print("99999999999999999999999999999999999999999999999999999999999999999999999999")
    j3+=1
    if j3==31:
        j2+=1
    if j2==12:
        j1+=1
    j2%=12
    j3%=31
print(zeller0(1900,2,25))
