import secrets

while True:
    try:
        c = int(input('\nNumero de dados (A):'))
        b = int(input('Espaco amostral (X):'))

        if b <= 0:
            print('O espaco amostral deve ser um inteiro positivo.')
            continue

        if c < 0:
            print('O numero de dados nao pode ser negativo.')
            continue

        print()

        for i in range(c):
            numero = secrets.randbelow(b) + 1
            print(f'Dado ({i+1}): {numero}')

    except ValueError:
        print('Digite apenas numeros inteiros.')
    print('\n' + '='*50)
