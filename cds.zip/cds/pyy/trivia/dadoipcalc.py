import secrets
import os


class Dado:
    sampleSpc = 1
    ip = 0
    cache = {}
    def __init__(self, sample):
        self.sample = sample

    @classmethod
    def cache_clear(cls):
        cls.cache.clear()

def calc_loop():
    while True:
        print('\n' + '-'*50)
        print(f'\nChance de reroll: {Dado.reroll_odds} em {Dado.sampleSpc} | {Dado.reroll_oddsP}%')
        print('\nDigite "sair" a qualquer momento no loop para alterar os status.')
        x = 0
        Dado.k = Dado.sampleSpc
        for i in range(len(Dado.samples)):
            numero_given = input(f'\nPonha o número que caiu no dado ({i+1}) de {Dado.samples[i]} lados:\n')
            if numero_given == 'sair':
                break
            numero_given = int(numero_given)
            if i+1 < len(Dado.samples):
                Dado.k = Dado.k//Dado.samples[i]
                x += Dado.k*(numero_given - 1)
            else:
                x += numero_given

        if numero_given == 'sair':
            break
        if x <= Dado.no_reroll_area:
            y = x%Dado.ip
            if y == 0:
                y = Dado.ip
            if Dado.mark != '':
                print(f'\nIp personalizado: 1 - {Dado.mark}')
            print(f'\nRoll: {y} de {Dado.ip}')
        else:
            print('\n[Reroll!]')

def main():
    while True:
        Dado.sampleSpc = 1
        print('\n-----Digite "sair" exatamente agora para sair do codigo-----')
        quantidade = input('\nQuantos dados:\n')
        if quantidade == 'sair':
            exit()
        quantidade = int(quantidade)

        Dado.ip = int(input('\nEspaco amostral desejado:\n'))
        Dado.mark = input('\nRegistrar anotacao para ip personalizado (opcional):\n')
        print('\n-----Aviso: Colocar de forma crescente. Do menor para o maior-----')

        for i in range(quantidade):
            dado_sample = int(input(f'\nEspaco amostral do dado ({i+1}):\n'))
            Dado.cache[i] = Dado(dado_sample)
            Dado.sampleSpc *= Dado.cache[i].sample

        Dado.reroll_odds = Dado.sampleSpc%Dado.ip
        Dado.reroll_oddsP = Dado.reroll_odds/Dado.sampleSpc * 100
        Dado.no_reroll_area = Dado.sampleSpc-Dado.reroll_odds
        Dado.samples = [i.sample for i in Dado.cache.values()]
        calc_loop()

        Dado.cache_clear()
        print('\n' + '='*50)


if __name__ == '__main__':
    main()
