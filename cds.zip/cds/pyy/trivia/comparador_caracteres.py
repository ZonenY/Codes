while True:
    a = input('\nString (1):\n')

    b = input('\nString (2):\n')

    print('\nResultado:','igual' if a == b else 'diferente')

    print('\n' + '='*50)
