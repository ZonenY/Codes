Dias0 = ["Quarta-feira","Quinta-feira","Sexta-feira","Sábado","Domingo","Segunda-feira","Terça-feira"]
def h(n,a):
    if n==2:
        return 1 if a%4==0 and (a%100!=0 or a%400==0) else 0
    elif n%2==0 and n<=7:
        return 2
    elif n%2==1 and n<=7:
        return 3
    elif n%2==0 and n>=8:
        return 3
    else:
        return 2
def calc(a,b,c):
    w=a-2026
    d,e,f,g=int(w/4),c%7,w%7,int((a-2000+(-1 if w>=0 else 1))/100)-int((a-2000+(-1 if w>=0 else 1))/400)
    x=d+e+f-g
    if w>=0 and w%4==3:
        x+=1
    elif w<0 and (w%4 in (1,2)):
        x=x-1+(1 if a%100==0 and a%400!=0 else 0)
    for i in range(b-1):
        x+=h(i+1,a)
    x%=7
    return x
while True:
    print("\n1: Dia da semana")
    print("2: Dias do mês")
    print("[digite /sair para sair]")
    R=input("\nO que você quer?\n")
    if R=="/sair":
        exit()
    print("")
    if R=="1":
        try:
            a,b,c=int(input("Ano:\n")),int(input("\nMês:\n")),int(input("\nDia:\n"))
        except ValueError:
            print("")
            print("[Erro. A entrada não é um número.]")
            T=True
            continue
        x = calc(a,b,c)
        print(f'\nResultado: [{Dias0[x]}]')
    elif R=="2":
        print("""Dias da semana:
Domingo
Segunda-feira
Terça-feira
Quarta-feira
Quinta-feira
Sexta-feira
Sábado""")
        print("")
        try:
            a,b,s=int(input("Ano:\n")),int(input("\nMês:\n")),str(input("\nDia da semana:\n"))
        except ValueError:
            print("")
            print("[Erro. A entrada não é um número.]")
            T=True
            continue
        if s not in Dias0:
            print("")
            print('[Erro. Tente escolher algo da lista "Dias da semana:".]')
            T=True
            continue
        print("")
        print("Dias:")
        for c in range(1,29+h(b,a)):
            x=calc(a,b,c)
            if x==Dias0.index(s):
                print("[{}]".format(c))
    else:
        print("[Comando inválido.]")
    print('\n' + '='*50)
