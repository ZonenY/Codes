while True:
    a=input('\nTexto:\n')
    L1=[]
    for i in range(len(a)):
        if a[i] not in L1:
            L1+=[a[i]]
    L1.sort()
    b=''.join(L1)
    c = len(a)
    print(f'\nCaracteres:\n{b}')
    print(f'\nQuantidade:\n{len(b)}')
    print(f'\nTamanho da string:\n{c}')
    print('\n' + '='*50)
