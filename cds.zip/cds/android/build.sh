gcc comparador_string.c -o comparador_stringC
