#include <SDL2/SDL.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("Programa iniciado\n");
    fflush(stdout);
    SDL_Init(SDL_INIT_VIDEO);

    SDL_Window *window =
        SDL_CreateWindow("Botao",
                         SDL_WINDOWPOS_CENTERED,
                         SDL_WINDOWPOS_CENTERED,
                         800, 600, 0);

    SDL_Renderer *renderer =
        SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    SDL_Rect button = {300, 250, 200, 100};

    int contador = 0;
    int running = 1;

    while (running) {

        SDL_Event e;

        while (SDL_PollEvent(&e)) {

            if (e.type == SDL_QUIT)
                running = 0;

            if (e.type == SDL_MOUSEBUTTONDOWN) {

                int x = e.button.x;
                int y = e.button.y;

                if (x >= button.x &&
                    x <= button.x + button.w &&
                    y >= button.y &&
                    y <= button.y + button.h)
                {
                    contador++;
                    printf("Contador = %d\n", contador);
                }
            }
        }

        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderDrawColor(renderer, 0, 120, 255, 255);
        SDL_RenderFillRect(renderer, &button);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
