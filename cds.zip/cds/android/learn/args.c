#include <stdio.h>

struct Coords{
    int x;
    int y;
    int z;
};

struct Coords scall(struct Coords a, int b);

int main(int argc, char* argv[]){
    int arr[3] = {0};
    for(int i=0; i<3; i++){
        sscanf(argv[i+1], "%d", &arr[i]);
    }
    struct Coords obj = {arr[0], arr[1], arr[2]};

    int j, k;
    sscanf(argv[4], "%d", &j);
    sscanf(argv[5], "%d", &k);
    struct Coords temp = scall(obj, k);
    switch(j){
        case 0:
            obj.x = temp.x;
            break;
	case 1:
   	    obj.y = temp.y;
	    break;
        case 2:
	    obj.z = temp.z;
	    break;
	default:
            printf("Erro de argumento.");
   	    return 1;
    }
    printf("Objetos: %d, %d, %d", obj.x, obj.y, obj.z);
    return 0;
}

struct Coords scall(struct Coords a, int b){
    struct Coords c = {a.x*b, a.y*b, a.z*b};
    return c;
}
