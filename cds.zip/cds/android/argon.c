#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include <argon2.h>

static void secure_zero(void *ptr, size_t len)
{
    volatile unsigned char *p = ptr;
    while (len--)
        *p++ = 0;
}

int main(void)
{
    uint32_t iterations;
    uint32_t memory_cost;
    uint32_t parallelism;
    uint32_t key_length;

    unsigned char password[1024];
    unsigned char salt[1024];

    printf("\nSenha:\n");
    fgets((char *)password, sizeof(password), stdin);

    printf("\nSalt:\n");
    fgets((char *)salt, sizeof(salt), stdin);

    password[strcspn((char *)password, "\n")] = 0;
    salt[strcspn((char *)salt, "\n")] = 0;

    printf("\nTamanho da chave:\n");
    scanf("%u", &key_length);

    printf("\nIteracoes:\n");
    scanf("%u", &iterations);

    printf("\nParalelismo:\n");
    scanf("%u", &parallelism);

    printf("\nMemory cost (KiB):\n");
    scanf("%u", &memory_cost);

    unsigned char *hash = malloc(key_length);

    if (!hash)
    {
        fprintf(stderr, "Erro de memoria\n");
        return 1;
    }

    int result = argon2id_hash_raw(
        iterations,
        memory_cost,
        parallelism,
        password,
        strlen((char *)password),
        salt,
        strlen((char *)salt),
        hash,
        key_length);

    if (result != ARGON2_OK)
    {
        fprintf(stderr, "Erro: %s\n",
                argon2_error_message(result));

        secure_zero(password, sizeof(password));
        secure_zero(salt, sizeof(salt));

        free(hash);
        return 1;
    }

    printf("\nHash:\n");

    for (uint32_t i = 0; i < key_length; i++)
        printf("%02x", hash[i]);

    printf("\n");

    secure_zero(password, sizeof(password));
    secure_zero(salt, sizeof(salt));
    secure_zero(hash, key_length);

    free(hash);

    return 0;
}
